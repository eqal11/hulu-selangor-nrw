# Synthetic Hulu Selangor NRW data

All data is synthetic, for demonstration only.

Run with Node.js 18 or later; no packages or network access are required:

```sh
node generate-data.js
```

The script writes six files to `data/` beside the script. Existing files with the same names are overwritten. Included files use the default seed, `20251023`. The same seed produces byte-identical files; no current timestamps enter the output.

```sh
node generate-data.js --seed 12345 --out-dir ./data-alternate
node generate-data.js --help
```

## Files

| File | Contents |
| --- | --- |
| `data/dma.geojson` | Eight fictional DMA polygons with population and connection counts. |
| `data/pipes.geojson` | 674 pipe LineStrings: 84 connected grid edges per DMA and two intentionally isolated segments. |
| `data/assets.geojson` | 112 points: ten valves, three flow meters and one inlet meter per DMA. |
| `data/leaks.geojson` | 66 leak reports with the default seed, each within approximately ten metres of a pipe centre line. Count varies by seed. |
| `data/water_balance.json` | Flat array of 96 records: January through December 2025 for every DMA. |
| `data/qa_injected_issues.json` | Seed, extent, issue counts and a feature-level log of every deliberate defect. |

GeoJSON uses WGS 84 / EPSG:4326, `[longitude, latitude]` coordinate order and no legacy `crs` member. The approximate extent is longitude 101.59 to 101.69 and latitude 3.49 to 3.54, around Hulu Selangor, Malaysia. Names evoke the district; polygons are fictional rectangles and do not represent actual locality boundaries, utility assets or surveyed DMA boundaries. Pipe lengths are geodesic endpoint distances in metres.

## Modelling assumptions

Each DMA has a jittered 7 by 7 node grid with exact shared endpoints. All pipe geometry lies inside its original DMA, including records whose DMA foreign key is intentionally corrupted. Each inlet meter marks a grid inlet node; no external supply main or hydraulic simulation is modelled. Pipe `status` is `in_service` or `needs_rehabilitation`. Asset `condition` is `good`, `fair` or `poor`.

Materials are DI, uPVC, AC, HDPE and steel. AC is assigned older installation years. Leak probability per eligible pipe is 5.5%, multiplied by 2 for AC and 2.2 for installation before 1995. Older AC pipes therefore have 24.2% probability. This creates an age/material bias without forcing every older pipe to leak. Leaks reference unique, valid pipe records; deliberately faulty pipes and duplicate-ID donors are excluded from sampling to avoid additional unlogged reference defects. Leak types are `burst`, `service connection` and `joint`; repair status is `open`, `in_progress` or `repaired`. Reports are dated in 2025. `est_loss_m3_day` describes daily loss while the leak was active, including for subsequently repaired leaks.

Monthly water balances are generated separately from individual reports, since reported leaks do not account for all real losses. There is no hydraulic or leak-duration reconciliation between the two datasets. Seasonal demand and monthly variation are synthetic. DMA-004, DMA-005 and DMA-007 consistently have elevated NRW (approximately 44% to 53%); the other five are approximately 23% to 35%. All records fall within 20% to 55%.

Volumes use cubic metres, rounded to two decimals using integer hundredths internally. Every monthly record satisfies:

```text
system_input_m3 = billed_authorised_m3 + nrw_m3
nrw_m3 = unbilled_authorised_m3 + apparent_losses_m3 + real_losses_m3
nrw_pct = round(100 * nrw_m3 / system_input_m3, 2)
```

## Deliberate QA/QC defects

There are 20 affected pipe records out of 674 (2.9674%). Each affected record has one injected defect:

| Issue | Count |
| --- | ---: |
| Null `material` | 6 |
| Null `install_year` | 6 |
| Duplicate `pipe_id` | 3 |
| Nonexistent `dma_id` | 3 |
| Disconnected pipe segment | 2 |

Use the GeoJSON feature `id` as the unique locator; business property `pipe_id` deliberately contains duplicates. The log gives the zero-based `features` array index, feature ID, original value and injected value. Duplicate records include the donor's feature ID/index. Isolated segments were added intentionally, so their original geometry is `null`. They lie in DMA-002 and DMA-006. The 3% rate counts modified or added pipe records, not all features across all layers and not both records participating in a duplicate pair. To recover the clean grids, restore logged original property values and remove the two added segments.

The generator validates expected defect counts, issue-log correspondence, polygon containment, shared endpoints, asset placement, leak proximity and references, geodesic lengths and water-balance identities before writing files. Imported callers can use `generateDataset(seed)` and `validateDataset(data)` from the script.
